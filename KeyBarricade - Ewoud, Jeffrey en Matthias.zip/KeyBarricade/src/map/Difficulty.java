package map;

public enum Difficulty {
    TEST,
    EASY,
    NORMAL,
    HARD,
    IMPOSSIBLE
}